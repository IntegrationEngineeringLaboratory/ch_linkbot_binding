// song.h

#ifndef _SONG_H
#define _SONG_H

#pragma package <chsong>

#include<pitches.h>

note_t Techno(int iter);
note_t HappyBirthday(int iter);
note_t LittleLamb(int iter);
note_t LittleStar(int iter);
note_t RingTone(int iter);
note_t OldMcDonald(int iter);
note_t JingleBells(int iter);
note_t RowYourBoat(int iter);
note_t DoReMi(int iter);
note_t Bingo(int iter);
note_t MerryChristmas(int iter);
note_t WheelsOnTheBus(int iter);
note_t IceCream(int iter);


#endif
